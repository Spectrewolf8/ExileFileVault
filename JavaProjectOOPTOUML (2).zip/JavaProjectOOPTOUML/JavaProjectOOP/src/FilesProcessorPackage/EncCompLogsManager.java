package FilesProcessorPackage;

import FilesPackage.FileToProcess;

import java.io.*;
import java.util.ArrayList;

public class EncCompLogsManager {
    private ArrayList<FileToProcess> fileToLogArr = new ArrayList<>();

    public void log(String encryptedHiddenFile) throws IOException {
        FileToProcess fileToLog = new FileToProcess(encryptedHiddenFile);

        File file = new File("enclogs.dat");
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        fileToLogArr.add(fileToLog);
        oos.writeObject(fileToLogArr);
        oos.close();
    }

    public ArrayList<FileToProcess> readLogs() throws IOException, ClassNotFoundException {
        ArrayList<FileToProcess> fileReadFromLog;
        File file = new File("enclogs.dat");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
        fileReadFromLog = (ArrayList<FileToProcess>) ois.readObject();
        ois.close();

        return fileReadFromLog;
    }

}