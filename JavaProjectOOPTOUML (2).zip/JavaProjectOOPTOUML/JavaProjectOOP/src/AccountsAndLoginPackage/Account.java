package AccountsAndLoginPackage;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.io.Serializable;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

public class Account implements Serializable {
    private String userName;
    private String masterPassword;

    private ArrayList<Password> accPasswords;
    private ArrayList<FileOfCurrentUser> FileOfCurrentUserArr;

    public Account(String userName, String masterPassword)
    {
        this.userName = userName;
        this.masterPassword = masterPassword;
        accPasswords= new ArrayList<>();
        FileOfCurrentUserArr = new ArrayList<>();
    }

    public Account()
    {
        userName=null;
        masterPassword= null;
        accPasswords= new ArrayList<>();
        FileOfCurrentUserArr = new ArrayList<>();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMasterPassword() {
        return masterPassword;
    }

    public void setMasterPassword(String masterPassword) {
        this.masterPassword = masterPassword;
    }


    public ArrayList<Password> getAccPasswords() {
        return accPasswords;
    }
    public void addAccToVault(String userName, String Password, String note) throws InvalidAlgorithmParameterException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeySpecException, InvalidKeyException, IOException, ClassNotFoundException {
        Password p = new Password(userName,Password,note);
        accPasswords.add(p);
        AccountData.updateAccountsFile(this);
    }
    public void deletePasswords(String name) throws IOException, ClassNotFoundException {
        for(int i=0;i<accPasswords.size();i++)
        {
            if(accPasswords.get(i).getName().equals(name))
            {
                accPasswords.remove(accPasswords.get(i));
            }

        }
        AccountData.updateAccountsFile(this);

    }
    public String DisplayPasswords(int i) {

        return(accPasswords.get(i).toString());

    }
    public void updatePasswords(String platform, String newPass) throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException, IOException, ClassNotFoundException {
        for (int i=0; i<accPasswords.size();i++)
        {
            if(accPasswords.get(i).getPlatform().equals(platform))
            {
                accPasswords.get(i).setPassword(newPass);
            }
        }
        AccountData.updateAccountsFile(this);
    }
    public void updatePasswordsname(String name, String newName) throws IOException, ClassNotFoundException {
        for (int i=0; i<accPasswords.size();i++)
        {
            if(accPasswords.get(i).getName().equals(name))
            {
                accPasswords.get(i).setName(name);
            }
        }
        AccountData.updateAccountsFile(this);
    }
    public void updatePasswordsnote(String name, String platform) throws IOException, ClassNotFoundException {
        for (int i=0; i<accPasswords.size();i++)
        {
            if(accPasswords.get(i).getName().equals(name))
            {
                accPasswords.get(i).setPlatform(platform);
            }
        }
        AccountData.updateAccountsFile(this);
    }

    public void updateVaultAccountDetails(String platform, String newPlatform, String newName, String newPass) throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException, IOException, ClassNotFoundException {
        for (int i=0; i<accPasswords.size();i++)
        {
            if(accPasswords.get(i).getPlatform().equals(platform))
            {
                accPasswords.get(i).setPlatform(newPlatform);
                accPasswords.get(i).setName(newName);
                accPasswords.get(i).setPassword(newPass);
            }
        }
        AccountData.updateAccountsFile(this);
    }

    public ArrayList<FileOfCurrentUser> getFilesOfCurrentUser()
    {
        return FileOfCurrentUserArr;
    }

    public FileOfCurrentUser getFile(int index) {
        return FileOfCurrentUserArr.get(index);
    }

    public void addFileToUser(String fileInVault,String originPath) throws IOException, ClassNotFoundException {
        FileOfCurrentUserArr.add(0,new FileOfCurrentUser(fileInVault,originPath));
        AccountData.updateAccountsFile(this);

    }
    public void addFileToUser(FileOfCurrentUser fileToAdd) throws IOException, ClassNotFoundException {
        FileOfCurrentUserArr.add(0,fileToAdd);
        AccountData.updateAccountsFile(this);
    }
    public void removeFileFromUser(int index){
        FileOfCurrentUserArr.remove(index);
    }
    public Password RetreiveDetails(String Platform){
        for(int i =0; i<accPasswords.size();i++)
        {
            if(accPasswords.get(i).getPlatform().equals(Platform))
            {
                return accPasswords.get(i);
            }

        }
        return null;
    }
}