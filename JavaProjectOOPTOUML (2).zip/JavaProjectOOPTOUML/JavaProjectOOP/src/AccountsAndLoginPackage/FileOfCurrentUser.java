package AccountsAndLoginPackage;

import java.io.Serializable;

public class FileOfCurrentUser implements Serializable {
    private String pathOfFileInVault;
    private String originPath;
private String securityHash;
    public FileOfCurrentUser(String pathOfFileInVault, String originPath) {
        this.pathOfFileInVault = pathOfFileInVault;
        this.originPath = originPath;
    }

    public String getOriginPath() {
        return originPath;
    }

    public String getPathOfFileInVault() {
        return pathOfFileInVault;
    }

    public void setOriginPath(String originPath) {
        this.originPath = originPath;
    }

    public void setPathOfFileInVault(String pathOfFileInVault) {
        this.pathOfFileInVault = pathOfFileInVault;
    }

    public void setSecurityHash(String securityHash) {
        this.securityHash = securityHash;
    }
    public Boolean matchPasswordHash(String securityHash){
        if (this.securityHash.equals(securityHash)){
            return true;
        }else{
            return false;
        }
    }
}