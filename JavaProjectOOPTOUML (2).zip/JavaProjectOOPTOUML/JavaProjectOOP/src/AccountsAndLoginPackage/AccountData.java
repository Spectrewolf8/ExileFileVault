package AccountsAndLoginPackage;

import java.io.*;
import java.util.ArrayList;

public class AccountData implements Serializable {
    private static ArrayList<Account> accountArr= new ArrayList<>();

    public  static void signUp(Account A) throws IOException {
        File file = new File("Accounts.dat");
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        boolean check = false;
        for(int i = 0; i<accountArr.size();i++) {
            if (accountArr.get(i).getMasterPassword().equals(A.getMasterPassword()) && accountArr.get(i).getUserName().equals(A.getUserName())) {
                check=true;
            }
        }
        if(check == false)
        {
            accountArr.add(A);
        }
        oos.writeObject(accountArr);
        oos.close();
    }

    public static Account login(String userName,String masterPassword) throws IOException, ClassNotFoundException {
        File file = new File("Accounts.dat");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
        accountArr=(ArrayList<Account>) ois.readObject();
        ois.close();
        for(int i=0;i<accountArr.size();i++)
        {
            if(accountArr.get(i).getMasterPassword().equals(masterPassword) && accountArr.get(i).getUserName().equals(userName))
            {
                return accountArr.get(i);
            }
        }
        return null;
    }
    public static void updateAccountsFile(Account a) throws IOException, ClassNotFoundException {
        File file = new File("Accounts.dat");
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
        accountArr=(ArrayList<Account>) ois.readObject();
        ois.close();
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        for(int i = 0; i<accountArr.size();i++)
        {
            if(accountArr.get(i).getMasterPassword().equals(a.getMasterPassword()) && accountArr.get(i).getUserName().equals(a.getUserName()))
            {
                accountArr.remove(i);
                accountArr.add(a);
            }
        }
        oos.writeObject(accountArr);
        oos.close();
    }
}
