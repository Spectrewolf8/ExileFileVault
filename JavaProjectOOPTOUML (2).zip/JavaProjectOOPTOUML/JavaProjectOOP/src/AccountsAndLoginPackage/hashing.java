package AccountsAndLoginPackage;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;


public class hashing {
    static SecretKeySpec skey;

    public static String encrypt(String text) throws NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException {
        String key = "1234567890abcdef";
        skey=new SecretKeySpec(key.getBytes(),"AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE,skey);
        byte[] ciphertext = cipher.doFinal(text.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(ciphertext);

    }
    public static String decrypt(String ciphertext) throws NoSuchPaddingException, NoSuchAlgorithmException,  InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE,skey);
        byte[] plaintxt = ciphertext.getBytes(StandardCharsets.UTF_8);
        byte[] original = cipher.doFinal(Base64.getDecoder().decode(plaintxt));
        return new String(original,StandardCharsets.UTF_8 );

    }
}
