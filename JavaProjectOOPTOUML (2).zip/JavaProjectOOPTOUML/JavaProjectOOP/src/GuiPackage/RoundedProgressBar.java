package GuiPackage;

import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.*;

public class RoundedProgressBar extends JProgressBar {
    private int progress;
    private Color color;

    public RoundedProgressBar() {

        //progress = 0;
        color = Color.ORANGE;
//        setContentAreaFilled(false);
//        setFocusPainted(false);
        setBorderPainted(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        // Paint the button as usual
        super.paintComponent(g);

        // Draw the progress bar
        int width = getWidth();
        int height = getHeight();
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(color);
        g2.fill(new RoundRectangle2D.Double(0, 0, width * progress / 100.0, height, height, height));
    }

    public void setProgress(int progress) {
        this.progress = progress;
        repaint();
    }

    public void setColor(Color color) {
        this.color = color;
        repaint();
    }

}