package GuiPackage;

import AccountsAndLoginPackage.Account;
import AccountsAndLoginPackage.AccountData;
import AccountsAndLoginPackage.FileOfCurrentUser;
import CompressionDecompressionPackage.CompressionModule;
import FilesPackage.FileToCompress;
import FilesPackage.FileToProcess;
import FilesProcessorPackage.FileVaultProcessor;
import FilesProcessorPackage.FilesBrowser;
import HashPackage.SHA512_HashGenerator;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.ECField;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.imageio.*;
import javax.swing.*;

import static AccountsAndLoginPackage.AccountData.*;
import static AccountsAndLoginPackage.Account.*;

public class GUI extends JFrame {
    int activePanel;


//======================================================================================================================
//File paths
//======================================================================================================================
    Icon logoIcon = new ImageIcon("E:\\JavaProjectOOP\\Images\\logo6.png");
    File bgFile = new File("E:\\JavaProjectOOP\\Images\\bgFinal.jpg");
    Icon backIcon = new ImageIcon("E:\\JavaProjectOOP\\Images\\back2E.png");
    Icon buttonIcon = new ImageIcon("E:\\JavaProjectOOP\\Images\\btn3.png");
    Icon compressButtonIcon = new ImageIcon("E:\\JavaProjectOOP\\Images\\cbtn2.png");
    Icon loginButtonIcon = new ImageIcon("E:\\JavaProjectOOP\\Images\\lbtn1.png");
    Icon addToVaultIcon = new ImageIcon("E:\\JavaProjectOOP\\Images\\addToVault.png");
    Icon removeFromVaultIcon = new ImageIcon("E:\\JavaProjectOOP\\Images\\removeFromVault.png");
    Icon editIcon = new ImageIcon("E:\\JavaProjectOOP\\Images\\editIcon.png");
//======================================================================================================================

    //======================================================================================================================
//Fonts
//======================================================================================================================
    Font f = new Font("League Spartan", 1, 15); //For headings
    Font f2 = new Font("League Spartan", 1, 32); //For buttons


//======================================================================================================================
//Panel Headings
//======================================================================================================================
    JLabel heading = new JLabel("Welcome to Filehub! Please select an option below:", SwingConstants.CENTER);
    JLabel loginHeading = new JLabel("Please login below to access your vault:", SwingConstants.CENTER);
    JLabel signupHeading = new JLabel("Please enter details below to complete signup:", SwingConstants.CENTER);
    JLabel cfHeading = new JLabel("Compression Menu", SwingConstants.CENTER);
    JLabel vHeading = new JLabel("Vault Menu", SwingConstants.CENTER);
    JLabel pvHeading = new JLabel("Password Vault Menu", SwingConstants.CENTER);
    JLabel fvHeading = new JLabel("File Vault Menu", SwingConstants.CENTER);

    //======================================================================================================================
//Buttons
//======================================================================================================================
    JComboBox compressionMethodsComboBox = new JComboBox(new String[]{"Fast - Large size, less time", "Normal - Average size & time", "Ultra - Small size, longer time"});

    JButton vaultButton = new JButton("Vault", buttonIcon);
    JButton cfButton = new JButton("Compress file", buttonIcon);
    JButton loginButton = new JButton("Log In", loginButtonIcon);
    JButton signupButton = new JButton("Sign up!");
    JButton completeSignupButton = new JButton("Sign up!", loginButtonIcon);
    JButton pvButton = new JButton("Password Vault", buttonIcon);
    JButton fvButton = new JButton("File Vault", buttonIcon);
    JButton[] backButtons = new JButton[6];
    JButton[] browseButton = new JButton[2];
    JButton compressButton = new JButton("COMPRESS", compressButtonIcon);
    JButton addToVaultButton = new JButton("Add File", addToVaultIcon);
    JButton removeFromVaultButton = new JButton("Remove File", removeFromVaultIcon);
    JButton addNewAccButton = new JButton("Add account", addToVaultIcon);
    JButton removeAccButton = new JButton("Remove account", removeFromVaultIcon);
    JButton modifyAccDetailsButton = new JButton("", editIcon);
    JButton confirmModifyAccButton = new JButton("Confirm");
    JButton cancelModifyAccButton = new JButton("Cancel");

    //======================================================================================================================
//TextFields - TF
//======================================================================================================================
    JTextField loginUsernameTF = new JTextField();
    JPasswordField loginPasswordTF = new JPasswordField();
    JTextField signupUsernameTF = new JTextField();
    JPasswordField signupPasswordTF = new JPasswordField();
    JTextField[] browsePathTF = new JTextField[2];
    JTextField compressionPassTF = new JTextField("(Enter zip password here)");

    JTextField[] accDetailsTF = new JTextField[3];


    //======================================================================================================================
//Labels - L
//======================================================================================================================
    JLabel logoL = new JLabel(logoIcon);
    JLabel loginError1L = new JLabel("ERROR: Invalid username/password!");
    JLabel loginError2L = new JLabel("ERROR: Please enter a username!");
    JLabel loginError3L = new JLabel("ERROR: Please enter a password!");
    JLabel loginUserL = new JLabel("Enter Username:");
    JLabel loginPassL = new JLabel("Enter Password:");
    JLabel signupL = new JLabel("Don't have an account? ");
    JLabel signupUserL = new JLabel("Enter a new username:");
    JLabel signupPassL = new JLabel("Enter a password:");
    JLabel cfSubHeading = new JLabel("Select a file to compress");
    JLabel cfFileAttrHeading = new JLabel("File Properties", SwingConstants.CENTER);
    JLabel[] cfFileAttr = new JLabel[5];
    JLabel fvSubHeading = new JLabel("Please select a file to add to or remove from vault", SwingConstants.CENTER);
    JLabel fvVaultFilesHeading = new JLabel("Vault Files", SwingConstants.CENTER);

    JLabel pvSubHeading = new JLabel("Please select an account to view/modify", SwingConstants.CENTER);
    JLabel pvStoredAccHeading = new JLabel("Stored Accounts", SwingConstants.CENTER);

    JLabel pvAccDetailsHeading = new JLabel("Account Details", SwingConstants.CENTER);
    JLabel[] pvAccAttr = new JLabel[3];

    RoundedProgressBar compressionPB = new RoundedProgressBar();

    FileVaultProcessor fileVaultProcessor = new FileVaultProcessor();
    DefaultListModel<String> filesList = new DefaultListModel<>();
    DefaultListModel<String> accList = new DefaultListModel<>();
    boolean loggedIn = false;
    Account loggedInAccount = null;

    public GUI() throws IOException, InvalidAlgorithmParameterException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeySpecException, InvalidKeyException { //Constructor start


        setLayout(null);

        for (int i = 0; i < 6; ++i) { //Back buttons config
            backButtons[i] = new JButton(backIcon);
            backButtons[i].setBounds(5, 15, 50, 38);
            backButtons[i].setOpaque(false);
            backButtons[i].setBackground(new Color(0x0FFFFFF, true));
            backButtons[i].setBorder(BorderFactory.createLineBorder(backButtons[i].getBackground(), 0));

        }


        logoL.setBounds(885, 15, 157, 65);
        logoL.setOpaque(false);
        logoL.setBackground(new Color(0x0FFFFFF, true));
        logoL.setBorder(BorderFactory.createLineBorder(logoL.getBackground(), 0));

//======================================================================================================================
//Panel 1 Start - Main Screen
//======================================================================================================================

        JPanel panel1 = new JPanel();

        panel1.setLayout(null);

        heading.setBounds(315, 40, 450, 25);
        heading.setFont(f);
        heading.setForeground(Color.white);


        vaultButton.setBounds(160, 175, 300, 200);
        cfButton.setBounds(2 * vaultButton.getX() + vaultButton.getWidth(), vaultButton.getY(), vaultButton.getWidth(), vaultButton.getHeight());

        vaultButton.setBackground(new Color(255, 255, 255, 0));
        vaultButton.setFont(f2);
        vaultButton.setForeground(new Color(0xE3353F));
        vaultButton.setHorizontalTextPosition(SwingConstants.CENTER);
        vaultButton.setBorder(BorderFactory.createLineBorder(vaultButton.getBackground(), 0));
        vaultButton.setOpaque(false);

        cfButton.setBackground(new Color(255, 255, 255, 0));
        cfButton.setFont(f2);
        cfButton.setForeground(new Color(0xE3353F));
        cfButton.setHorizontalTextPosition(SwingConstants.CENTER);
        cfButton.setBorder(BorderFactory.createLineBorder(vaultButton.getBackground(), 0));
        cfButton.setOpaque(false);


        panel1.add(logoL);
        panel1.add(heading);
        panel1.add(vaultButton);
        panel1.add(cfButton);
        panel1.setOpaque(false);
//======================================================================================================================

//======================================================================================================================
//Panel 2 Start - Vault login - succeeds panel 1
//======================================================================================================================
        JPanel panel2 = new JPanel();

        panel2.setLayout(null);

        loginHeading.setBounds(315, 40, 450, 25);
        loginHeading.setFont(f);
        loginHeading.setForeground(Color.white);

        //Container loginPanel = getContentPane();
        JPanel loginPanel = new JPanel();

        //loginPanel.setLayout(new GroupLayout(loginPanel));
        loginPanel.setLayout(null);
        loginPanel.setBounds(365, 100, 350, 300);
        loginPanel.setBackground(new Color(0x161616));


        loginUsernameTF.setBounds(25, 50, 300, 50);
        loginUsernameTF.setBackground(new Color(0x3F3E3E));
        loginUsernameTF.setForeground(Color.white);
        loginUsernameTF.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));

        loginPasswordTF.setBounds(loginUsernameTF.getX(), loginUsernameTF.getY() + 90, loginUsernameTF.getWidth(), loginUsernameTF.getHeight());
        loginPasswordTF.setBackground(new Color(0x3F3E3E));
        loginPasswordTF.setForeground(Color.white);
        loginPasswordTF.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));

        loginUserL.setBounds(loginUsernameTF.getX(), loginUsernameTF.getY() - 30, loginUsernameTF.getWidth(), 25);
        loginUserL.setForeground(Color.white);
        loginPassL.setBounds(loginPasswordTF.getX(), loginPasswordTF.getY() - 30, loginPasswordTF.getWidth(), 25);
        loginPassL.setForeground(Color.white);

        loginButton.setBounds(loginUsernameTF.getX(), loginUsernameTF.getY() + 160, loginUsernameTF.getWidth(), 50);
        loginButton.setBackground(new Color(229, 59, 59, 255));
        loginButton.setForeground(Color.white);
        loginButton.setHorizontalTextPosition(SwingConstants.CENTER);
        loginButton.setBorder(BorderFactory.createLineBorder(loginButton.getBackground(), 0));
        loginButton.setOpaque(false);

        loginError1L.setBounds(loginButton.getX(), loginButton.getY() + 50, loginButton.getWidth(), 25);
        loginError1L.setForeground(Color.red);

        loginError2L.setBounds(loginButton.getX(), loginButton.getY() + 50, loginButton.getWidth(), 25);
        loginError2L.setForeground(Color.red);

        loginError3L.setBounds(loginButton.getX(), loginButton.getY() + 50, loginButton.getWidth(), 25);
        loginError3L.setForeground(Color.red);

        signupL.setBounds(loginButton.getX(), loginButton.getY() + 65, loginButton.getWidth(), 25);
        signupL.setForeground(Color.white);
        signupButton.setBounds(signupL.getX() + 120, signupL.getY(), 75, 25);
        signupButton.setBackground(new Color(0x0FFFFFF, true));
        signupButton.setForeground(new Color(229, 59, 59, 255));
        signupButton.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 0), 0));
        signupButton.setOpaque(false);
        signupButton.setFocusable(false);


        loginPanel.add(signupButton);
        loginPanel.add(signupL);
        loginPanel.add(loginUserL);
        loginPanel.add(loginPassL);
        loginPanel.add(loginUsernameTF);
        loginPanel.add(loginPasswordTF);
        loginPanel.add(loginButton);

        panel2.add(backButtons[0]);
        panel2.add(loginPanel);
        panel2.add(loginHeading);
        panel2.setOpaque(false);
//======================================================================================================================

//======================================================================================================================
//Panel 3 Start - CF
//======================================================================================================================
        JPanel panel3 = new JPanel();
        panel3.setLayout(null);

        cfHeading.setBounds(315, 40, 450, 25);
        cfHeading.setFont(f);
        cfHeading.setForeground(Color.white);

        System.out.println(cfHeading.getText().length());

        JPanel cfPanel = new JPanel();
        cfPanel.setLayout(null);

        cfPanel.setBounds(100, 100, 880, 400);
        cfPanel.setBackground(new Color(0x161616));
        cfPanel.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));


        cfSubHeading.setBounds(185, 45, 200, 25);
        cfSubHeading.setFont(f);
        cfSubHeading.setForeground(new Color(229, 59, 59, 255));

        browseButton[0] = new JButton("Browse");
        browseButton[0].setBounds(420, 115, 125, 60);
        browseButton[0].setFont(new Font(f2.getFontName(), 1, 12));
        browseButton[0].setBackground(Color.white);
        browseButton[0].setForeground(new Color(229, 59, 59, 255));
        browseButton[0].setBorder(BorderFactory.createLineBorder(browseButton[0].getBackground(), 0));

        browsePathTF[0] = new JTextField("Browse to select file path");
        browsePathTF[0].setBounds(25, browseButton[0].getY(), 385, 25);
        browsePathTF[0].setBorder(BorderFactory.createLineBorder(browsePathTF[0].getBackground(), 0));
        browsePathTF[0].setEnabled(false);

        compressionMethodsComboBox.setBounds(25, browseButton[0].getY() + 35, 190, 25);
        compressionMethodsComboBox.setEnabled(false);

        compressionPassTF.setBounds(220, compressionMethodsComboBox.getY(), 190, 25);
        compressionPassTF.setBorder(BorderFactory.createLineBorder(compressionPassTF.getBackground(), 0));
        compressionPassTF.setEnabled(false);


        compressButton.setBounds(25, browseButton[0].getY() + 75, 520, 75);
        compressButton.setFont(f2);
        compressButton.setBackground(new Color(0x161616));
        compressButton.setForeground(new Color(229, 59, 59, 255));
        compressButton.setHorizontalTextPosition(SwingConstants.CENTER);
        compressButton.setBorder(BorderFactory.createLineBorder(compressButton.getBackground(), 0));
        compressButton.setFocusable(false);
        compressButton.setOpaque(false);
        compressButton.setEnabled(false);

        compressionPB.setBounds(25, browseButton[0].getY() + 185, 520, 50);
        compressionPB.setFont(f2);
        compressionPB.setBackground(new Color(0x161616));
        compressionPB.setForeground(new Color(0x161616));
        compressionPB.setColor(new Color(229, 59, 59, 255));
        //compressionPB.setProgress(50);


        //File Attributes panel
        JPanel cfSubPanel = new JPanel();
        cfSubPanel.setLayout(null);

        cfSubPanel.setBounds(570, 25, 300, 350);
        cfSubPanel.setBackground(new Color(0x161616));
        cfSubPanel.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));

        cfFileAttrHeading.setBounds(10, 20, 280, 25);
        cfFileAttrHeading.setFont(f);
        cfFileAttrHeading.setForeground(new Color(0xE3353F));


        cfFileAttr[0] = new JLabel("Name: " + "");
        cfFileAttr[1] = new JLabel("Type: " + "");
        cfFileAttr[2] = new JLabel("Size: " + "");
        cfFileAttr[3] = new JLabel("Created On: " + "");
        cfFileAttr[4] = new JLabel("Last Modified: " + "");

        for (int i = 0; i < 5; i++) {
            cfFileAttr[i].setBounds(10, ((50 * i) - 75), 280, 300);
            cfFileAttr[i].setForeground(Color.WHITE);
            //cfFileAttr[i].setFont();
            cfSubPanel.add(cfFileAttr[i]);
        }


        cfSubPanel.add(cfFileAttrHeading);
        cfPanel.add(cfSubPanel);

        cfPanel.add(compressionPB);
        cfPanel.add(compressionPassTF);
        cfPanel.add(compressionMethodsComboBox);
        cfPanel.add(compressButton);
        cfPanel.add(cfSubHeading);
        cfPanel.add(browseButton[0]);
        cfPanel.add(browsePathTF[0]);
        panel3.add(cfPanel);
        panel3.add(backButtons[1]);
        panel3.add(cfHeading);
        panel3.setOpaque(false);
//======================================================================================================================

//======================================================================================================================
//Panel 4 Start - Vault - Succeeds panel 2
//======================================================================================================================
        JPanel panel4 = new JPanel();

        panel4.setLayout(null);


        vHeading.setBounds(315, 40, 450, 25);
        vHeading.setFont(f);
        vHeading.setForeground(Color.white);

        pvButton.setBounds(vaultButton.getBounds());
        fvButton.setBounds(cfButton.getBounds());

        pvButton.setBackground(vaultButton.getBackground());
        fvButton.setBackground(cfButton.getBackground());

        pvButton.setForeground(vaultButton.getForeground());
        fvButton.setForeground(cfButton.getForeground());

        pvButton.setFont(f2);
        fvButton.setFont(f2);

        pvButton.setOpaque(false);
        fvButton.setOpaque(false);

        pvButton.setHorizontalTextPosition(SwingConstants.CENTER);
        fvButton.setHorizontalTextPosition(SwingConstants.CENTER);

        pvButton.setBorder(BorderFactory.createLineBorder(vaultButton.getBackground(), 0));
        fvButton.setBorder(BorderFactory.createLineBorder(vaultButton.getBackground(), 0));

        panel4.add(backButtons[2]);
        panel4.add(vHeading);
        panel4.add(pvButton);
        panel4.add(fvButton);
        panel4.setOpaque(false);
//======================================================================================================================

//======================================================================================================================
//Panel 5 Start - Password Vault - Succeeds panel 4
//======================================================================================================================
        JPanel panel5 = new JPanel();

        panel5.setLayout(null);

        pvHeading.setBounds(315, 40, 450, 25);
        pvHeading.setFont(f);
        pvHeading.setForeground(Color.white);

        JPanel pvPanel = new JPanel();
        pvPanel.setLayout(null);

        pvPanel.setBounds(100, 100, 880, 400);
        pvPanel.setBackground(new Color(0x161616));
        pvPanel.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));

        //========

        pvSubHeading.setBounds(233, 10, 415, 25);
        pvSubHeading.setFont(f);
        pvSubHeading.setForeground(new Color(229, 59, 59, 255));


        addNewAccButton.setBounds(180, 315, 255, 75);
        addNewAccButton.setFont(f2);
        addNewAccButton.setBackground(new Color(0x161616));
        addNewAccButton.setForeground(new Color(229, 59, 59, 255));
        addNewAccButton.setHorizontalTextPosition(SwingConstants.CENTER);
        addNewAccButton.setBorder(BorderFactory.createLineBorder(addNewAccButton.getBackground(), 0));
        addNewAccButton.setOpaque(false);
        //addNewAccButton.setEnabled(false);

        removeAccButton.setBounds(445, 315, 255, 75);
        removeAccButton.setFont(f2);
        removeAccButton.setBackground(new Color(0x161616));
        removeAccButton.setForeground(new Color(229, 59, 59, 255));
        removeAccButton.setHorizontalTextPosition(SwingConstants.CENTER);
        removeAccButton.setBorder(BorderFactory.createLineBorder(removeAccButton.getBackground(), 0));
        removeAccButton.setOpaque(false);
        removeAccButton.setEnabled(false);


        //Acc panel
        JPanel pvSubPanel = new JPanel();
        pvSubPanel.setLayout(null);

        pvSubPanel.setBounds(10, 40, 550, 270);
        pvSubPanel.setBackground(new Color(0x161616));
        pvSubPanel.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));

        pvStoredAccHeading.setBounds(135, 7, 280, 25);
        pvStoredAccHeading.setFont(f);
        pvStoredAccHeading.setForeground(new Color(0xE3353F));


        JList<String> storedAcc = new JList<>(accList);
        storedAcc.setBounds(1, 35, 778, 200);
        storedAcc.setBackground(new Color(0x161616));
        storedAcc.setForeground(new Color(0xFFFFFF));
        storedAcc.setFont(new Font(storedAcc.getFont().getFontName(), 0, 20));
        storedAcc.setSelectionBackground(new Color(0xE3353F));
        storedAcc.setSelectionForeground(new Color(0xFFFFFF));


        JScrollPane pvScrollPane = new JScrollPane(storedAcc, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        pvScrollPane.setBounds(1, 35, 548, 200);
        pvScrollPane.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 255), 0));


        //Acc details panel
        JPanel pvDetailsPanel = new JPanel();
        pvDetailsPanel.setLayout(null);

        pvDetailsPanel.setBounds(570, 40, 300, 270); //h
        pvDetailsPanel.setBackground(new Color(0x161616));
        pvDetailsPanel.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));


        pvAccDetailsHeading.setBounds(10, 7, 280, 25);
        pvAccDetailsHeading.setFont(f);
        pvAccDetailsHeading.setForeground(new Color(0xE3353F));


        pvAccAttr[0] = new JLabel("Platform: " + "");
        pvAccAttr[1] = new JLabel("User Name: " + "");
        pvAccAttr[2] = new JLabel("Password: " + "");

        for (int i = 0; i < 3; i++) {
            pvAccAttr[i].setBounds(10, ((65 * i) - 80), 280, 300);
            pvAccAttr[i].setForeground(Color.WHITE);

            pvDetailsPanel.add(pvAccAttr[i]);


            accDetailsTF[i] = new JTextField();
            accDetailsTF[i].setBounds(80, pvAccAttr[i].getY() + 140, 200, 25);
            accDetailsTF[i].setBorder(BorderFactory.createLineBorder(new Color(0xE3353F), 1));
            accDetailsTF[i].setBackground(new Color(0x3F3E3E));
            accDetailsTF[i].setForeground(new Color(0xFFFFFF));

        }

        confirmModifyAccButton.setBounds(75, 225, 45, 35);
//            removeAccButton.setFont(f2);
        confirmModifyAccButton.setBackground(new Color(255, 255, 255, 255));
        confirmModifyAccButton.setForeground(new Color(229, 59, 59, 255));
        confirmModifyAccButton.setHorizontalTextPosition(SwingConstants.CENTER);
        confirmModifyAccButton.setBorder(BorderFactory.createLineBorder(confirmModifyAccButton.getBackground(), 0));
        confirmModifyAccButton.setOpaque(false);
        confirmModifyAccButton.setEnabled(true);


        cancelModifyAccButton.setBounds(175, 225, 45, 35);
//            removeAccButton.setFont(f2);
        cancelModifyAccButton.setBackground(new Color(255, 255, 255, 255));
        cancelModifyAccButton.setForeground(new Color(229, 59, 59, 255));
        cancelModifyAccButton.setHorizontalTextPosition(SwingConstants.CENTER);
        cancelModifyAccButton.setBorder(BorderFactory.createLineBorder(confirmModifyAccButton.getBackground(), 0));
        cancelModifyAccButton.setOpaque(false);
        cancelModifyAccButton.setEnabled(true);


        modifyAccDetailsButton.setBounds(240, 210, 50, 50);
        modifyAccDetailsButton.setBackground(new Color(0x161616));
        modifyAccDetailsButton.setBorder(BorderFactory.createLineBorder(removeAccButton.getBackground(), 0));
        modifyAccDetailsButton.setOpaque(false);


        pvDetailsPanel.add(pvAccDetailsHeading);
        pvPanel.add(pvDetailsPanel);


        pvSubPanel.add(pvScrollPane);
        pvSubPanel.add(pvStoredAccHeading);

        pvPanel.add(pvSubPanel);

        pvPanel.add(pvSubHeading);
        pvPanel.add(addNewAccButton);
        pvPanel.add(removeAccButton);

        panel5.add(pvPanel);


        panel5.add(backButtons[3]);
        panel5.add(pvHeading);
        panel5.setOpaque(false);
//======================================================================================================================

//======================================================================================================================
//Panel 6 Start - File Vault - Succeeds panel 4
//======================================================================================================================
        JPanel panel6 = new JPanel();

        panel6.setLayout(null);


        fvHeading.setBounds(315, 40, 450, 25);
        fvHeading.setFont(f);
        fvHeading.setForeground(Color.white);


        JPanel fvPanel = new JPanel();
        fvPanel.setLayout(null);

        fvPanel.setBounds(100, 100, 880, 400);
        fvPanel.setBackground(new Color(0x161616));
        fvPanel.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));


        fvSubHeading.setBounds(233, 10, 415, 25);
        fvSubHeading.setFont(f);
        fvSubHeading.setForeground(new Color(229, 59, 59, 255));


        browseButton[1] = new JButton("Browse");
        browseButton[1].setBounds(575, 277, 125, 25);
        browseButton[1].setFont(new Font(f2.getFontName(), 1, 12));
        browseButton[1].setBackground(Color.white);
        browseButton[1].setForeground(new Color(229, 59, 59, 255));
        browseButton[1].setBorder(BorderFactory.createLineBorder(browseButton[1].getBackground(), 0));
        browseButton[1].setFocusable(false);

        browsePathTF[1] = new JTextField("Browse to select file path");
        browsePathTF[1].setBounds(180, browseButton[1].getY(), 385, 25);
        browsePathTF[1].setBorder(BorderFactory.createLineBorder(browsePathTF[1].getBackground(), 0));
        browsePathTF[1].setEnabled(false);


        addToVaultButton.setBounds(180, 315, 255, 75);
        addToVaultButton.setFont(f2);
        addToVaultButton.setBackground(new Color(0x161616));
        addToVaultButton.setForeground(new Color(229, 59, 59, 255));
        addToVaultButton.setHorizontalTextPosition(SwingConstants.CENTER);
        addToVaultButton.setBorder(BorderFactory.createLineBorder(addToVaultButton.getBackground(), 0));
        addToVaultButton.setOpaque(false);
        addToVaultButton.setEnabled(false);

        removeFromVaultButton.setBounds(445, 315, 255, 75);
        removeFromVaultButton.setFont(f2);
        removeFromVaultButton.setBackground(new Color(0x161616));
        removeFromVaultButton.setForeground(new Color(229, 59, 59, 255));
        removeFromVaultButton.setHorizontalTextPosition(SwingConstants.CENTER);
        removeFromVaultButton.setBorder(BorderFactory.createLineBorder(removeFromVaultButton.getBackground(), 0));
        removeFromVaultButton.setOpaque(false);
        removeFromVaultButton.setEnabled(false);


        //Vault panel
        JPanel fvSubPanel = new JPanel();
        fvSubPanel.setLayout(null);

        fvSubPanel.setBounds(50, 40, 780, 270);
        fvSubPanel.setBackground(new Color(0x161616));
        fvSubPanel.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));

        fvVaultFilesHeading.setBounds(250, 5, 280, 25);
        fvVaultFilesHeading.setFont(f);
        fvVaultFilesHeading.setForeground(new Color(0xE3353F));


        JList<String> vaultFiles = new JList<>(filesList);
        vaultFiles.setBounds(1, 35, 778, 200);
        vaultFiles.setBackground(new Color(0x161616));
        vaultFiles.setForeground(new Color(0xFFFFFF));
        vaultFiles.setFont(new Font(vaultFiles.getFont().getFontName(), 0, 20));
        vaultFiles.setSelectionBackground(new Color(0xE3353F));
        vaultFiles.setSelectionForeground(new Color(0xFFFFFF));




        JScrollPane scrollPane = new JScrollPane(vaultFiles, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBounds(1, 35, 778, 200);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 255), 0));


        fvPanel.add(browseButton[1]);
        fvPanel.add(browsePathTF[1]);
        fvSubPanel.add(scrollPane);
        fvSubPanel.add(fvVaultFilesHeading);

        fvPanel.add(fvSubPanel);

        fvPanel.add(fvSubHeading);
        fvPanel.add(addToVaultButton);
        fvPanel.add(removeFromVaultButton);

        panel6.add(fvPanel);

        panel6.add(backButtons[4]);
        panel6.add(fvHeading);
        panel6.setOpaque(false);

//======================================================================================================================


//======================================================================================================================
//Panel 7 Start - Signup - succeeds panel 2
//======================================================================================================================
        JPanel panel7 = new JPanel();

        panel7.setLayout(null);

        signupHeading.setBounds(315, 40, 450, 25);
        signupHeading.setFont(f);
        signupHeading.setForeground(Color.white);

        //Container loginPanel = getContentPane();
        JPanel signupPanel = new JPanel();

        //loginPanel.setLayout(new GroupLayout(loginPanel));
        signupPanel.setLayout(null);
        signupPanel.setBounds(365, 100, 350, 300);
        signupPanel.setBackground(new Color(0x161616));


        signupUsernameTF.setBounds(25, 50, 300, 50);
        signupUsernameTF.setBackground(new Color(0x3F3E3E));
        signupUsernameTF.setForeground(Color.white);
        signupUsernameTF.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));

        signupPasswordTF.setBounds(loginUsernameTF.getX(), loginUsernameTF.getY() + 90, loginUsernameTF.getWidth(), loginUsernameTF.getHeight());
        signupPasswordTF.setBackground(new Color(0x3F3E3E));
        signupPasswordTF.setForeground(Color.white);
        signupPasswordTF.setBorder(BorderFactory.createLineBorder(new Color(229, 59, 59, 255), 1));

        signupUserL.setBounds(loginUsernameTF.getX(), loginUsernameTF.getY() - 30, loginUsernameTF.getWidth(), 25);
        signupUserL.setForeground(Color.white);
        signupPassL.setBounds(loginPasswordTF.getX(), loginPasswordTF.getY() - 30, loginPasswordTF.getWidth(), 25);
        signupPassL.setForeground(Color.white);

        completeSignupButton.setBounds(loginUsernameTF.getX(), loginUsernameTF.getY() + 160, loginUsernameTF.getWidth(), 50);
        completeSignupButton.setBackground(new Color(229, 59, 59, 255));
        completeSignupButton.setForeground(Color.white);
        completeSignupButton.setHorizontalTextPosition(SwingConstants.CENTER);
        completeSignupButton.setBorder(BorderFactory.createLineBorder(loginButton.getBackground(), 0));
        completeSignupButton.setOpaque(false);


        signupPanel.add(signupUserL);
        signupPanel.add(signupPassL);
        signupPanel.add(signupUsernameTF);
        signupPanel.add(signupPasswordTF);
        signupPanel.add(completeSignupButton);

        panel7.add(backButtons[5]);
        panel7.add(signupPanel);
        panel7.add(signupHeading);
        panel7.setOpaque(false);
//======================================================================================================================


//======================================================================================================================
//Background printing
//======================================================================================================================
        try {
            final Image backgroundImage = ImageIO.read(bgFile);
            setContentPane(new JPanel(new BorderLayout()) {
                public void paintComponent(Graphics g) {
                    g.drawImage(backgroundImage, 0, 0, (ImageObserver) null);
                }
            });
        } catch (IOException var9) {
            throw new RuntimeException(var9);
        }
//======================================================================================================================


        activePanel = 1;
        add(panel1);


//======================================================================================================================
//Buttons event handling
//======================================================================================================================

        backButtons[0].addActionListener((e) -> {
            remove(panel2);
            add(panel1);
            panel1.add(logoL);
            activePanel = 1;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        backButtons[1].addActionListener((e) -> {
            remove(panel3);
            add(panel1);
            panel1.add(logoL);
            activePanel = 1;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        backButtons[2].addActionListener((e) -> {
            remove(panel4);

            if (loggedIn) {
                for (int i = 0; i < accList.size(); i++) {
                    accList.clear();
                }
                for (int i = 0; i < filesList.size(); i++) {
                    filesList.clear();
                }
            }

            loggedIn = false;
            loggedInAccount = null;
            loginUsernameTF.setText("");
            loginPasswordTF.setText("");

            add(panel2);
            panel2.add(logoL);
            activePanel = 2;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        backButtons[3].addActionListener((e) -> {
            storedAcc.clearSelection();
            removeAccButton.setEnabled(false);
            for (int i = 0; i < 3; i++) {
                pvDetailsPanel.add(accDetailsTF[i]);
                pvDetailsPanel.remove(accDetailsTF[i]);
            }
            pvDetailsPanel.remove(confirmModifyAccButton);
            pvDetailsPanel.remove(cancelModifyAccButton);
            pvDetailsPanel.remove(modifyAccDetailsButton);

            remove(panel5);
            add(panel4);
            panel4.add(logoL);
            activePanel = 4;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        backButtons[4].addActionListener((e) -> {
            vaultFiles.clearSelection();
            removeFromVaultButton.setEnabled(false);
            remove(panel6);
            add(panel4);
            panel4.add(logoL);
            activePanel = 4;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        backButtons[5].addActionListener((e) -> {
            signupUsernameTF.setText("");
            signupPasswordTF.setText("");

            remove(panel7);
            add(panel2);
            panel2.add(logoL);
            activePanel = 2;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        vaultButton.addActionListener((e) -> {
            loginPanel.remove(loginError1L);
            loginPanel.remove(loginError2L);
            loginPanel.remove(loginError3L);
            loginUsernameTF.setText("");
            loginPasswordTF.setText("");

            remove(panel1);
            activePanel = 2;
            add(panel2);
            panel2.add(logoL);
            activePanel = 2;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        cfButton.addActionListener((e) -> {
            remove(panel1);
            activePanel = 3;
            add(panel3);
            panel3.add(logoL);

            compressionPB.setValue(0);
            compressionPB.setProgress(0);
            compressionPB.update(compressionPB.getGraphics());

            activePanel = 3;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        loginButton.addActionListener((e) -> {
            loginPanel.remove(loginError1L);
            loginPanel.remove(loginError2L);
            loginPanel.remove(loginError3L);


            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);


            if (loginUsernameTF.getText().equals("")) {
                loginPanel.add(loginError2L);
            } else if (loginPasswordTF.getText().equals("")) {
                loginPanel.add(loginError3L);
            } else {


                try {
                    loggedInAccount = login(loginUsernameTF.getText(), loginPasswordTF.getText());
                    if (loggedInAccount == null) {
                        loginPanel.add(loginError1L);

                        loggedIn = false;


                        //To refresh/update frame
                        setSize(1079, 549);
                        setSize(1080, 550);
                    } else {
                        loggedIn = true;
                        System.out.println("default");
                        for (int i = 0; i < loggedInAccount.getAccPasswords().size(); i++) {
                            loggedInAccount.DisplayPasswords(i);
                        }


                        for (int i = 0; i < loggedInAccount.getFilesOfCurrentUser().size(); i++) {

                            String fileName = loggedInAccount.getFilesOfCurrentUser().get(i).getOriginPath().toString();

                            int index = fileName.lastIndexOf("\\");
                            if (index > -1) {
                                fileName = fileName.substring(index + 1);

                                filesList.add(0, fileName);
                            }

                        }
                        //System.out.println(loginUsernameTF.getText());
                        //System.out.println(loginPasswordTF.getText());
                        //System.out.println(loggedInAccount.getUserName() + "\n" + loggedInAccount.getMasterPassword() + "\n" + loggedInAccount.getAccPasswords() + "\n" + loggedInAccount.getFilesOfCurrentUser());


                        for (int i = 0; i < loggedInAccount.getAccPasswords().size(); i++) {
                            loggedInAccount.DisplayPasswords(i);
                            accList.add(0, loggedInAccount.getAccPasswords().get(i).getPlatform());
                            storedAcc.setSelectedIndex(-1);

                        }


                        remove(panel2);
                        activePanel = 4;
                        add(panel4);
                        panel4.add(logoL);
                        activePanel = 4;

                    }
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                } catch (ClassNotFoundException ex) {
                    throw new RuntimeException(ex);
                }
            }
            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);


        });

        pvButton.addActionListener((e) -> {
            remove(panel4);
            activePanel = 5;
            add(panel5);
            panel5.add(logoL);
            activePanel = 5;


            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        fvButton.addActionListener((e) -> {
            remove(panel4);
            activePanel = 6;
            add(panel6);
            panel6.add(logoL);
            activePanel = 6;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        browseButton[0].addActionListener((e) -> {
            FilesBrowser filesBrowser = new FilesBrowser();
            FileToProcess fileToProcess;
            browsePathTF[0].setText(filesBrowser.browseFile());
            if (browsePathTF[0].getText().equalsIgnoreCase("Browse to select file path") || browsePathTF[0].getText().equals("")) {
                compressButton.setEnabled(false);
                compressionMethodsComboBox.setEnabled(false);
                compressionPassTF.setEnabled(false);
                System.out.println("cfA false");
                cfFileAttr[0].setText("Name: " + "NIL");
                cfFileAttr[1].setText("Type: " + "NIL");
                cfFileAttr[2].setText("Size: " + "NIL");
                cfFileAttr[3].setText("Created On: " + "NIL");
                cfFileAttr[4].setText("Last Modified: " + "NIL");
            } else {

                //compressButton.setEnabled(true);
                compressionMethodsComboBox.setEnabled(true);
                compressionPassTF.setEnabled(true);
                try {
                    fileToProcess = new FileToProcess(browsePathTF[0].getText());
                    System.out.println("cfA true");
                    cfFileAttr[0].setText("Name: " + fileToProcess.getFileName());
                    cfFileAttr[1].setText("Type: " + fileToProcess.getFileExtension());
                    cfFileAttr[2].setText("Size: " + fileToProcess.getFileSize() + " bytes");
                    cfFileAttr[3].setText("Created On: " + fileToProcess.getStringFileCreationTime());
                    cfFileAttr[4].setText("Last Modified: " + fileToProcess.getStringFileModifiedTime());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

            }

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        compressButton.addActionListener((e) -> {
            System.out.println("index: " + compressionMethodsComboBox.getSelectedIndex());

            CompressionModule compressionModule = new CompressionModule();
            compressionModule.setCompressionLevel(compressionMethodsComboBox.getSelectedIndex());

            try {
                //module to remove last folder from destination path find the index of the last slash in the file path for decompressed files
                int lastSlashIndex = browsePathTF[0].getText().lastIndexOf("\\");
                // Extract the file path up to the last slash
                String newFilePath = browsePathTF[0].getText().substring(0, lastSlashIndex + 1);
                compressionModule.compressToZip(new FileToCompress(browsePathTF[0].getText(), browsePathTF[0].getText() + ".zip"), compressionPassTF.getText());
                compressionModule.runCompressionProgressBar(compressionPB);

            } catch (IOException ex) {
                throw new RuntimeException(ex);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }

            //To refresh/update frame
            panel3.setSize(1079, 549);
            panel3.setSize(1080, 550);
        });

        browseButton[1].addActionListener((e) -> {
            FilesBrowser filesBrowser = new FilesBrowser();
            FileToProcess fileToProcess;
            browsePathTF[1].setText(filesBrowser.browseFile());
            if (browsePathTF[1].getText().equalsIgnoreCase("Browse to select file path") || browsePathTF[1].getText().equals("")) {
                addToVaultButton.setEnabled(false);
            } else {
                addToVaultButton.setEnabled(true);
            }
            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });


        vaultFiles.addListSelectionListener(((e) -> {
            System.out.println("in: " + vaultFiles.getSelectedIndex());
            System.out.println("val: " + vaultFiles.getSelectedValue());
            if (vaultFiles.getSelectedIndex() != -1) {
                removeFromVaultButton.setEnabled(true);

            }

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        }));

        removeFromVaultButton.addActionListener((e) -> {
            String pass = JOptionPane.showInputDialog(this, "Enter file password:", null);
            System.out.println("entered pass: " + pass);
            if (!pass.equalsIgnoreCase("") && loggedInAccount.getFile(vaultFiles.getSelectedIndex()).matchPasswordHash(SHA512_HashGenerator.generateHash(pass))) {


                    FileOfCurrentUser ftp = loggedInAccount.getFile(vaultFiles.getSelectedIndex());
                    try {
                        fileVaultProcessor.unVault(ftp.getPathOfFileInVault(), ftp.getOriginPath(), pass);
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }

                    filesList.remove(vaultFiles.getSelectedIndex());
                    vaultFiles.clearSelection();
                    removeFromVaultButton.setEnabled(false);

            } else {
                JOptionPane.showMessageDialog(this, "ERROR: Password Invalid!!");
            }

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        addToVaultButton.addActionListener((e) -> {
            String pass = JOptionPane.showInputDialog(this, "Set file password:", null);
            if (!pass.equalsIgnoreCase("")) {
                try {
                    FileToProcess ftp = new FileToProcess(browsePathTF[1].getText());
                    filesList.add(0, ftp.getFileName());
                    fileVaultProcessor.vault(browsePathTF[1].getText(), pass);
                    loggedInAccount.addFileToUser(fileVaultProcessor.getEncryptedDestinationPath(), browsePathTF[1].getText());
                    loggedInAccount.getFile(0).setSecurityHash(SHA512_HashGenerator.generateHash(pass));
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }

                vaultFiles.clearSelection();
                removeFromVaultButton.setEnabled(false);
                addToVaultButton.setEnabled(false);
                browsePathTF[1].setText("Browse to select file path");

                //To refresh/update frame
                setSize(1079, 549);
                setSize(1080, 550);

            } else {
                JOptionPane.showMessageDialog(this, "ERROR: Password cannot be empty!");
            }
        });

        MouseListener mouseListener = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (compressionPassTF.getText().equalsIgnoreCase("(Enter zip password here)")) {
                    compressionPassTF.setText("");
                }
            }
        };

        compressionPassTF.addMouseListener(mouseListener);

        compressionPassTF.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (!compressionPassTF.getText().equalsIgnoreCase("(Enter zip password here)") && !compressionPassTF.getText().equalsIgnoreCase("")) {
                    compressButton.setEnabled(true);
                } else {
                    compressButton.setEnabled(false);
                }
            }
        });

        storedAcc.addListSelectionListener(((e) -> {
            System.out.println("in: " + storedAcc.getSelectedIndex());
            System.out.println("val: " + storedAcc.getSelectedValue());
            if (storedAcc.getSelectedIndex() != -1) {
                pvDetailsPanel.add(modifyAccDetailsButton);
                removeAccButton.setEnabled(true);
                pvAccAttr[0].setText("Platform: " + storedAcc.getSelectedValue());
                pvAccAttr[1].setText("User Name: " + loggedInAccount.RetreiveDetails(storedAcc.getSelectedValue()).getName());
                try {
                    pvAccAttr[2].setText("Password: " + loggedInAccount.RetreiveDetails(storedAcc.getSelectedValue()).getPassword());
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }

            } else {
                pvDetailsPanel.remove(modifyAccDetailsButton);
                removeAccButton.setEnabled(false);
                pvAccAttr[0].setText("Platform: " + "NIL");
                pvAccAttr[1].setText("User Name: " + "NIL");
                pvAccAttr[2].setText("Password: " + "NIL");

            }

            for (int i = 0; i < 3; i++) {
                pvDetailsPanel.remove(accDetailsTF[i]);
            }
            pvDetailsPanel.remove(confirmModifyAccButton);
            pvDetailsPanel.remove(cancelModifyAccButton);


            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        }));

        addNewAccButton.addActionListener((e) -> {
            storedAcc.clearSelection();
            pvAccAttr[0].setText("Platform: ");
            pvAccAttr[1].setText("User Name: ");
            pvAccAttr[2].setText("Password: ");
            for (int i = 0; i < 3; i++) {
                pvDetailsPanel.add(accDetailsTF[i]);
                accDetailsTF[i].setText("");
                pvDetailsPanel.add(accDetailsTF[i]);
            }
            pvDetailsPanel.remove(modifyAccDetailsButton);
            pvDetailsPanel.add(confirmModifyAccButton);
            pvDetailsPanel.add(cancelModifyAccButton);


            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });

        removeAccButton.addActionListener((e) -> {

            accList.remove(storedAcc.getSelectedIndex());
            storedAcc.clearSelection();
            removeAccButton.setEnabled(false);

            for (int i = 0; i < 3; i++) {
                pvDetailsPanel.add(accDetailsTF[i]);
                pvDetailsPanel.remove(accDetailsTF[i]);
            }
            pvDetailsPanel.remove(confirmModifyAccButton);
            pvDetailsPanel.remove(cancelModifyAccButton);
            pvDetailsPanel.remove(modifyAccDetailsButton);

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);

        });

        confirmModifyAccButton.addActionListener((e) -> {
            if (storedAcc.getSelectedIndex() == -1) //Check if new acc is being added
            {
                accList.add(0, accDetailsTF[0].getText());
                try {
                    loggedInAccount.addAccToVault(accDetailsTF[1].getText(), accDetailsTF[2].getText(), accDetailsTF[0].getText());
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }

                storedAcc.setSelectedIndex(0);
            } else //check if existing acc is being modified
            {
                try {
                    loggedInAccount.updateVaultAccountDetails(loggedInAccount.RetreiveDetails(storedAcc.getSelectedValue()).getPlatform(), accDetailsTF[0].getText(), accDetailsTF[1].getText(), accDetailsTF[2].getText());
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
                accList.add(storedAcc.getSelectedIndex(), accDetailsTF[0].getText());
                accList.remove(storedAcc.getSelectedIndex() + 1);
            }


            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);

        });
        cancelModifyAccButton.addActionListener((e) -> {
            storedAcc.clearSelection();
            removeAccButton.setEnabled(false);

            for (int i = 0; i < 3; i++) {
                pvDetailsPanel.add(accDetailsTF[i]);
                pvDetailsPanel.remove(accDetailsTF[i]);
            }
            pvDetailsPanel.remove(confirmModifyAccButton);
            pvDetailsPanel.remove(cancelModifyAccButton);
            pvDetailsPanel.remove(modifyAccDetailsButton);

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);

        });

        modifyAccDetailsButton.addActionListener((e) -> {
            pvAccAttr[0].setText("Platform: ");
            pvAccAttr[1].setText("User Name: ");
            pvAccAttr[2].setText("Password: ");

            accDetailsTF[0].setText(storedAcc.getSelectedValue());
            accDetailsTF[1].setText(loggedInAccount.RetreiveDetails(storedAcc.getSelectedValue()).getName());

            try {
                accDetailsTF[2].setText(loggedInAccount.RetreiveDetails(storedAcc.getSelectedValue()).getPassword());
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }

            for (int i = 0; i < 3; i++) {
                pvDetailsPanel.add(accDetailsTF[i]);
            }
            pvDetailsPanel.remove(modifyAccDetailsButton);
            pvDetailsPanel.add(confirmModifyAccButton);
            pvDetailsPanel.add(cancelModifyAccButton);


            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);

        });

        signupButton.addActionListener((e) -> {
            signupUsernameTF.setText("");
            signupPasswordTF.setText("");

            remove(panel2);
            add(panel7);
            panel7.add(logoL);
            activePanel = 7;

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });
        completeSignupButton.addActionListener((e) -> {
            signupPanel.remove(loginError2L);
            signupPanel.remove(loginError3L);

            if (signupUsernameTF.getText().equals("")) {
                signupPanel.add(loginError2L);
            } else if (signupPasswordTF.getText().equals("")) {
                signupPanel.add(loginError3L);
            } else {
                remove(panel7);
                add(panel2);
                panel2.add(logoL);
                activePanel = 2;
                try {
                    signUp(new Account(signupUsernameTF.getText(), signupPasswordTF.getText()));
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                if (loggedIn) {
                    for (int i = 0; i < accList.size(); i++) {

                        accList.clear();
                    }
                    for (int i = 0; i < filesList.size(); i++) {
                        filesList.clear();
                    }

                }
                loggedInAccount = null;
                loggedIn = false;

            }

            //To refresh/update frame
            setSize(1079, 549);
            setSize(1080, 550);
        });
//======================================================================================================================


    } //Constructor end


} //class end


