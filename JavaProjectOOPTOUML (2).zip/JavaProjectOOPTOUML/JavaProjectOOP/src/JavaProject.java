import AccountsAndLoginPackage.Account;
import FilesPackage.FileToProcess;
import FilesProcessorPackage.FileVaultProcessor;
import FilesProcessorPackage.FilesBrowser;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

import static AccountsAndLoginPackage.AccountData.signUp;

public class JavaProject {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InvalidAlgorithmParameterException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException, InterruptedException, InvalidKeySpecException {
        GuiPackage.GUI frame = new GuiPackage.GUI();
        frame.setSize(1080, 550);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setTitle("FileHub");
        frame.setVisible(true);
        frame.setDefaultCloseOperation(3);


        //Account a = new Account("admin", "admin");

        //signUp(a);

    }
}